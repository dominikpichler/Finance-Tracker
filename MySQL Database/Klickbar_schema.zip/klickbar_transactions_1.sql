-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: klickbar
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transactions_1`
--

DROP TABLE IF EXISTS `transactions_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions_1` (
  `transacton_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `month` varchar(45) NOT NULL,
  `date` datetime NOT NULL,
  `typ` varchar(45) NOT NULL,
  `amout` float NOT NULL,
  `text` varchar(45) NOT NULL,
  PRIMARY KEY (`transacton_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions_1`
--

LOCK TABLES `transactions_1` WRITE;
/*!40000 ALTER TABLE `transactions_1` DISABLE KEYS */;
INSERT INTO `transactions_1` VALUES (1,1,'March','2020-03-24 12:51:03','inc',100,'Gehalt'),(2,1,'March','2020-03-24 12:54:48','exp',200,'Auto'),(3,1,'March','2020-03-24 15:14:31','inc',1000,'Webnique'),(4,1,'March','2020-03-24 15:15:09','inc',3000,'Klickbar - Gehalt'),(5,1,'March','2020-03-24 15:15:22','inc',2600,'Klickbar-Provision'),(7,1,'March','2020-03-24 15:27:11','exp',800,'Miete'),(8,1,'March','2020-03-24 15:27:20','exp',400,'Essen'),(9,1,'March','2020-03-24 15:27:27','exp',100,'IT'),(11,1,'March','2020-03-25 10:22:28','inc',200,'Test'),(12,1,'May','2020-05-25 10:22:28','inc',5000,'Gewinn'),(13,1,'April','2020-04-05 10:22:28','inc',500,'April I'),(14,1,'April','2020-03-15 10:22:28','inc',1000,'April II'),(15,1,'April','2020-04-08 10:22:28','inc',1500,'April III'),(16,1,'April','2020-04-19 10:22:28','inc',1000,'April VI'),(17,1,'May','2020-05-01 10:22:28','inc',1320,'May I'),(18,1,'May','2020-05-09 10:22:28','inc',1500,'May II'),(19,1,'May','2020-05-12 10:22:28','inc',2020,'May III'),(20,1,'May','2020-05-19 10:22:28','inc',4500,'May VI'),(21,1,'May','2020-05-29 10:22:28','inc',3500,'May V'),(22,1,'June','2020-06-01 10:22:28','inc',2320,'June I'),(23,1,'June','2020-06-09 10:22:28','inc',1500,'June II'),(24,1,'June','2020-06-12 10:22:28','inc',4020,'June III'),(25,1,'June','2020-06-19 10:22:28','inc',9500,'June VI'),(26,1,'June','2020-06-29 10:22:28','inc',2500,'June V'),(27,1,'July','2020-07-05 10:22:28','inc',4420,'June I'),(28,1,'July','2020-07-09 10:22:28','inc',2500,'June II'),(29,1,'July','2020-07-12 10:22:28','inc',4320,'June III'),(30,1,'July','2020-07-19 10:22:28','inc',2100,'June VI'),(31,1,'July','2020-07-29 10:22:28','inc',3500,'June V'),(32,1,'July','2020-07-05 10:22:28','inc',4420,'June I'),(33,1,'July','2020-07-09 10:22:28','inc',2500,'June II'),(34,1,'July','2020-07-12 10:22:28','inc',4320,'June III'),(35,1,'July','2020-07-19 10:22:28','inc',2100,'June VI'),(36,1,'July','2020-07-29 10:22:28','inc',3500,'June V'),(37,1,'August','2020-07-05 10:22:28','inc',1420,'August I'),(38,1,'August','2020-07-09 10:22:28','inc',500,'August II'),(39,1,'August','2020-07-12 10:22:28','inc',1320,'August III'),(40,1,'August','2020-07-19 10:22:28','inc',1100,'August VI'),(41,1,'August','2020-07-29 10:22:28','inc',1500,'August V'),(42,1,'month','2020-04-05 10:22:28','exp',200,'Test'),(43,1,'month','2020-03-24 12:51:03','exp',200,'Test'),(44,1,'month','2020-03-24 12:51:03','exp',200,'Test');
/*!40000 ALTER TABLE `transactions_1` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 12:37:08
